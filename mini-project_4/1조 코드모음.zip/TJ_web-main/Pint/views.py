from django.shortcuts import render,redirect

# Create your views here.

def hello_world(request):

    if request.method == 'POST':
         temp = request.POST.get('helloworld')
         return redirect('/Pint/')
    else:
         return render(request, 'Pint/Helloworld.html', context={'text': 'get method'})