import pandas as pd
import os
import django
from django.db import transaction
from django.utils import timezone
import pytz
from datetime import datetime

# Django 설정
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'TJ_web.settings')
django.setup()

from steam.models import GameInfo, GameReview

# CSV 파일 읽기
game_info_df = pd.read_csv('game_info_final.csv')
game_review_df = pd.read_csv('game_review.csv')

# 데이터를 청크로 나누어 처리
CHUNK_SIZE = 1000

# def process_game_info():
#     for chunk in pd.read_csv('game_info_final.csv', chunksize=CHUNK_SIZE):
#         with transaction.atomic():
#             for _, row in chunk.iterrows():
#                 GameInfo.objects.update_or_create(
#                     title=row['game_name'],
#                     defaults={
#                         'genres': row['game_genres'],
#                         'image': row['game_image'],
#                         'price': row['game_price'],
#                         'release_date': row['game_release_date'],
#                         'mean_playtime': row['playtime_at_review'],
#                     }
#                 )

for _, row in game_review_df.iterrows():
    try:
        game_info = GameInfo.objects.get(title=row['game_name'])
        
        # 'timestamp_created'가 문자열일 경우 datetime 객체로 변환
        created_at_str = row['timestamp_created']
        
        # 문자열을 datetime 객체로 변환 (예시: '2024-09-25 04:10:00' 포맷)
        created_at = datetime.strptime(created_at_str, '%Y-%m-%d %H:%M:%S')
        
        # naive datetime일 경우 timezone-aware datetime으로 변환
        if created_at.tzinfo is None:
            created_at = timezone.make_aware(created_at, timezone=pytz.UTC)
        
        game_review = GameReview(
            game_info=game_info,
            content=row['review_text'],
            recommend=row['review_score'],
            playtime=row['playtime_at_review'],
            created_at=created_at,
        )
        game_review.save()
    
    except GameInfo.DoesNotExist:
        print(f"GameInfo에 해당 게임이 존재하지 않습니다: {row['game_name']}")
    except Exception as e:
        print(f"알 수 없는 오류가 발생했습니다: {str(e)}")