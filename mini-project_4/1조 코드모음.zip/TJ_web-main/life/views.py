from django.shortcuts import render, HttpResponse, redirect
from django.views.decorators.csrf import csrf_exempt
nextid = 5
topics = [
  {'id': 1, 'title': '엄', 'body': '엄마가'},
  {'id': 2, 'title': '준', 'body': '준비한'},
  {'id': 3, 'title': '식', 'body': '식사상'}
]

def HTMLTemplate(articleTag,id=None):
  global topics
  contextUI = ''
  if id != None:
    contextUI = f'''
      <li>
          <form action="/life/delete/" method='POST'>
            <input type='hidden' name='id' value={id}>
            <input type='submit' value='delete'>
          </form>
      </li>
    '''
  li = ''
  for topic in topics:
    li += f'<li><a href="/life/read/{topic["id"]}">{topic["title"]}</a></li>'
  return f'''
  <html>
  <body>
    <h1><a href="/life">반갑다</a></h1>
    <ol>
        {li}
    </ol>
    {articleTag}
    <ul>
      <li><a href="/life/create/">글쓰기</a></li>
      {contextUI}
    </ul>                    
  <body>
  <html>                                                                                                                          
'''

def index(request):
  article = '''
  <h2>Welcome</h2>
  Hello, 어머련
'''
  return HttpResponse(HTMLTemplate(article))

def read(request, id):
  global topics
  for topic in topics:
    if topic['id'] == int(id):
      article = f'''
      <h2>{topic['title']}</h2>
      {topic['body']}
      '''
      return HttpResponse(HTMLTemplate(article,id))
# p태그는 단락(줄바꿈)
@csrf_exempt
def create(request):
  global nextid
  if request.method == 'GET':
    article = '''
    <form action="/life/create/" method = "post">
    <p><input type="text" name="title" placeholder="제목을 입력해 여행자"></p>
    <p><textarea name="body" placeholder="내용"></textarea></p>
    <p><input type="submit" value="저장"></p>
    </form>
    '''
    return HttpResponse(HTMLTemplate(article))
  elif request.method == 'POST':
    title = request.POST['title']
    content = request.POST['body']
    new_paper = {'id': nextid, 'title': title, 'body': content}
    topics.append(new_paper)
    url = '/life/read/' + str(nextid)
    nextid += 1
    return redirect(url)

@csrf_exempt
def delete(request):
  global topics
  if request.method == "POST":
    id = request.POST['id']
    newTopics = []
    for topic in topics:
      if topic['id'] != int(id):
        newTopics.append(topic)
    topics = newTopics
    return redirect('/life')
