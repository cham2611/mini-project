from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.main, name ='index'),
    path('community/', views.community_list),
    path('community/<id>/update/', views.update, name= 'update'),
    path('community/<id>/', views.read, name= 'read'),
    path('create/', views.create, name = 'create'),
    path('community/<id>/delete/', views.delete, name= 'delete'),
    path('community/<id>/recommend/', views.post_recommend, name= 'post_recommend'),
    path('comment/edit/<int:comment_id>/', views.edit_comment, name='edit_comment'),
    path('comment/<int:comment_id>/com_delete/', views.delete_comment, name='delete_comment'),

    path('load-more-games/<str:genre>/', views.load_more_games, name='load_more_games'),
    path('game/<id>/', views.game_detail, name= 'game_detail'),
    
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', views.signup, name='signup'),

    path('<str:genre>/', views.game_genre, name='game_genre'),
]
