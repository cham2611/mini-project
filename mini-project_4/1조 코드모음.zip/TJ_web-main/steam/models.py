from django.db import models
from django.core import validators
from django.contrib.auth.models import User
class community(models.Model):
    id = models.AutoField(primary_key=True)  # integer - pk - auto increment
    title = models.CharField(
        "제목",
        max_length=255,
        validators=[validators.MinLengthValidator(1, "제목은 1글자 이상이어야 합니다.")],
    )  # varchar(255)
    content = models.TextField(
        "내용",
        validators=[validators.MinLengthValidator(1, "내용은 1글자 이상이어야 합니다.")],
    )  # text
    nickname = models.CharField(
        "닉네임",
        max_length=50,
        validators=[validators.MinLengthValidator(1, "닉네임 입력하쇼.")],
    )
    created_at = models.DateTimeField(
        auto_now_add=True)  # 추가될 때 default로 현재 시간
    updated_at = models.DateTimeField(
        auto_now=True)  # 추가 or 업데이트 될 때 default로 현재 시간
    is_deleted = models.BooleanField(default=False)
    hits = models.IntegerField(default = 0)
    recommend = models.IntegerField(default = 0)
    recommended_by = models.ManyToManyField(User, related_name='recommended_posts', blank=True)
    
class com_comment(models.Model):
    community = models.ForeignKey(community, on_delete=models.SET_NULL, null=True)
    nickname = models.CharField(max_length=50)
    content = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)

# 게임 정보 테이블
class GameInfo(models.Model):
    id = models.AutoField(primary_key=True)  # integer - pk - auto increment
    title = models.CharField(max_length=255)  # 게임 이름
    genres = models.CharField(max_length=255)  # 게임 장르
    image = models.URLField()  # 게임 이미지 URL
    price = models.DecimalField(max_digits=10, decimal_places=2)  # 게임 가격
    release_date = models.DateField()  # 게임 출시 날짜
    mean_playtime = models.FloatField(null=True, blank=True)  # 평균 플레이 시간


# 게임 리뷰 테이블
class GameReview(models.Model):
    game_info = models.ForeignKey(GameInfo, on_delete=models.CASCADE)  # GameInfo와 연결된 외래 키
    content = models.TextField()  # 리뷰 텍스트
    recommend = models.IntegerField()  # 리뷰 점수
    playtime = models.FloatField()  # 리뷰 작성 당시 플레이 시간
    created_at = models.DateTimeField()  # 리뷰 작성 시간
