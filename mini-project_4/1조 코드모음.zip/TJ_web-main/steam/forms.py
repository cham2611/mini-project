from django import forms
from .models import community, com_comment
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class CommunityForm(forms.ModelForm):
    class Meta:
        model = community
        fields = ['title', 'content','nickname']  # 폼에 나타낼 필드 설정

class CommentForm(forms.ModelForm):
    class Meta:
        model = com_comment
        fields = ['content','nickname', 'community']  
        widgets = {"content": forms.TextInput(attrs={"placeholder": "댓글 입력"})}
class SignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

