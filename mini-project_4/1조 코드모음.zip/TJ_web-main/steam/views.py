from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.views import LoginView
from .forms import SignUpForm, CommunityForm, CommentForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from .models import community, com_comment, GameInfo, GameReview
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import random
import json
from django.core.paginator import Paginator
from django.http import JsonResponse
from .word_cloud import generate_wordcloud


def game_genre(request, genre):
    games = GameInfo.objects.filter(genres__icontains=genre)
    paginator = Paginator(games, 6)  # 6개씩 페이지네이션
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'steam/game-genre.html', {
        'games': page_obj,
        'genre': genre,
        'game_count': games.count()
    })

def load_more_games(request, genre):
    games = GameInfo.objects.filter(genres__icontains=genre)
    paginator = Paginator(games, 6)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)
    
    data = [{
        'id': game.id,
        'title': game.title,
        'image': game.image,
        'genres': game.genres,
        'release_date': game.release_date
    } for game in page_obj]
    
    return JsonResponse({
        'games': data,
        'has_next': page_obj.has_next()
    })

def game_detail(request, id):
    game = get_object_or_404(GameInfo, id=id)
    reviews = GameReview.objects.filter(game_info=game)
    review_count = reviews.count()
    wordcloud_image = generate_wordcloud(reviews)
    game.price = int(game.price)
    game.mean_playtime = int(game.mean_playtime)
    for review in reviews:
        review.playtime = int(review.playtime)
    recommend_rate = int(reviews.filter(recommend=1).count() / review_count * 100)
    unrecommend_rate = 100 - recommend_rate
    return render(request, 'steam/game-detail.html', {'game': game, 'reviews': reviews, 'review_count': review_count, 'wordcloud_image': wordcloud_image, 'recommend_rate': recommend_rate, 'unrecommend_rate': unrecommend_rate})

def main(request):
    games = list(GameInfo.objects.all())
    random_games = random.sample(games, 9)
    return render(request, 'steam/main.html', {'random_games': random_games})

# 자유게시판(community)
def community_list(request):
    community_list = community.objects.filter(is_deleted=False)

    return render(request, 'steam/community-list.html', {'community_list': community_list})


def read(request, id):
    com_post = get_object_or_404(community, id=id)
    comment_list = com_post.com_comment_set.all()
    comment_count = com_post.com_comment_set.filter(is_deleted=False).count()
    form = CommentForm()
    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(f'/steam/community/{id}/')

    else:
        com_post.hits += 1
        com_post.save()
        form = CommentForm(initial={'nickname': request.user.username, 'community':id})
        return render(
        request,
        "steam/community-detail.html",
        {
            "com_post": com_post,
            "comment_list": comment_list,
            "comment_count": comment_count,
            "form": form
        }
    )

@login_required
def post_recommend(request, id):
    com_post = get_object_or_404(community, id=id)
    user = request.user

    if user in com_post.recommended_by.all():
        # 이미 추천한 경우 추천 취소
        com_post.recommended_by.remove(user)
        com_post.recommend -= 1
    else:
        # 추천하지 않은 경우 추천 추가
        com_post.recommended_by.add(user)
        com_post.recommend += 1

    com_post.save()
    return redirect(f'/steam/community/{id}/', id=id)

@login_required
def create(request):
         form = CommunityForm()
         if request.method == 'POST':
            form = CommunityForm(request.POST)
            if form.is_valid():
               form.save()
               return redirect('/steam/community/')
         else:
            form = CommunityForm(initial={'nickname': request.user.username})
            return render(request, 'steam/community-create.html', {'form': form})
         
@login_required         
def update(request, id):
         com_post = get_object_or_404(community, id=id)
         if request.method == 'POST':
            form = CommunityForm(request.POST, instance=com_post)
            if form.is_valid():
               form.save()
               return redirect(f'/steam/community/{id}/')
         else:
            form = CommunityForm(instance=com_post)
            return render(request, 'steam/community-update.html', {'form': form})
         
@login_required
def delete(request, id):
        com_post = get_object_or_404(community, id=id)
        if request.method == "POST":
            if not com_post.is_deleted:
                com_post.is_deleted = True
                com_post.save()
                messages.success(request, "게시글이 삭제되었습니다.")
            return redirect("/steam/community/")
        else:
            return redirect(f'/steam/community/{id}')
# 댓글 UD   
@csrf_exempt
def edit_comment(request, comment_id):
    if request.method == 'POST':
        comment = com_comment.objects.get(id=comment_id)
        data = json.loads(request.body)
        comment.content = data.get('content')
        comment.save()
        return JsonResponse({'updated_content': comment.content})

@csrf_exempt
def delete_comment(request, comment_id):
        com_post = get_object_or_404(com_comment, id=comment_id)
        if request.method == "POST":
            if not com_post.is_deleted:
                com_post.is_deleted = True
                com_post.save()
                print("삭제 성공")
                messages.success(request, "댓글이 삭제되었습니다.")
            return redirect(f'/steam/community/{com_post.community.id}')
        else:
            return redirect(f'/steam/community/{com_post.community.id}')
    


# 로그인 페이지
class CustomLoginView(LoginView):
    template_name = 'registration/login.html'
    redirect_authenticated_user = True

 
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.data.get("username")
            password = form.data.get("password1")
            user = authenticate(username=username, password=password)
            login(request, user)  # 자동 로그인
            return redirect('/steam/')  # 회원가입 후 이동할 페이지
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)  # 사용자 세션을 삭제하여 로그아웃 처리
    return redirect('/steam/')  # 로그아웃 후 리다이렉트할 URL