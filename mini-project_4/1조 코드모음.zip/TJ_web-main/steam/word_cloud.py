import nltk
from nltk.corpus import stopwords
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# 필요한 nltk 데이터 다운로드 (처음 한 번만 실행)
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')
# nltk.download('stopwords')
# nltk.download('punkt_tab')
# nltk.download('averaged_perceptron_tagger_eng')

def generate_wordcloud(reviews):
    # 모든 리뷰 내용을 하나의 문자열로 병합
    text = " ".join([review.content for review in reviews])
    
    # 리뷰 내용을 토큰화
    tokens = nltk.word_tokenize(text)
    
    # 불용어(의미 없는 단어들) 제거
    stop_words = set(stopwords.words('english'))
    stop_words.update(['game','gameplay','play','cant'])
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words and word.isalpha()]

    # 품사 태깅
    tagged_tokens = nltk.pos_tag(filtered_tokens)

    # 명사(NN) 또는 형용사(JJ)로 분류된 단어만 사용
    meaningful_words = [word for word, tag in tagged_tokens if tag.startswith('NN') or tag.startswith('JJ')]

    # 워드클라우드 생성
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(" ".join(meaningful_words))

    # 워드클라우드를 이미지로 변환
    buffer = BytesIO()
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.tight_layout(pad=0)
    
    # 이미지 데이터를 base64로 인코딩하여 템플릿에 전달
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    image_base64 = base64.b64encode(image_png).decode('utf-8')

    return image_base64
