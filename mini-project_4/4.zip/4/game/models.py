from django.db import models

# Create your models here.
from django.db import models

class User(models.Model):
    id = models.BigAutoField(primary_key=True)  # ID (bigint, AI)
    password = models.CharField(max_length=128)  # 비밀번호
    last_login = models.DateTimeField(null=True, blank=True)  # 마지막 로그인
    is_superuser = models.BooleanField(default=False)  # 슈퍼유저 여부
    username = models.CharField(max_length=150)  # 사용자 이름
    first_name = models.CharField(max_length=150)  # 이름
    last_name = models.CharField(max_length=150)  # 성
    email = models.EmailField(max_length=254)  # 이메일
    is_staff = models.BooleanField(default=False)  # 직원 여부
    is_active = models.BooleanField(default=True)  # 활성 여부
    date_joined = models.DateTimeField(auto_now_add=True)  # 가입일
    phone_number = models.CharField(max_length=13, null=True, blank=True)  # 전화번호
    profile = models.CharField(max_length=100, null=True, blank=True)  # 프로필

    class Meta:
        db_table = 'account_user'  # 기존 테이블 이름 지정


class Comment(models.Model):
    user = models.ForeignKey(User, related_name='comments', on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)