from django.shortcuts import render, redirect
from django.db import connection
from .models import Comment, User  # Comment와 User 모델을 가져옵니다.

def home(request):
    return render(request, 'home.html')  # home.html 템플릿을 렌더링합니다.

def user_list(request):
    # 데이터베이스에서 사용자 정보를 가져옵니다.
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM account_user;")
        users = cursor.fetchall()

    # 사용자 정보를 딕셔너리 형식으로 변환하고 각 사용자의 댓글도 가져옵니다.
    users_dict = [
        {
            'id': user[0],
            'username': user[4],
            'first_name': user[5],
            'last_name': user[6],
            'email': user[7],
            'date_joined': user[10],
            'phone_number': user[11],
            'profile': user[12],
            'comments': Comment.objects.filter(user_id=user[0]),  # 해당 사용자의 댓글 가져오기
        }
        for user in users
    ]

    # 사용자 정보를 포함한 템플릿을 렌더링합니다.
    return render(request, 'user_list.html', {'users': users_dict})

def add_comment(request, user_id):
    if request.method == 'POST':
        content = request.POST.get('content')  # POST 요청으로 전달된 댓글 내용을 가져옵니다.
        user = User.objects.get(id=user_id)  # 해당 ID의 사용자를 가져옵니다.
        Comment.objects.create(user=user, content=content)  # 댓글을 저장합니다.
        return redirect('user_list')  # 댓글 저장 후 사용자 목록으로 리디렉션합니다.


