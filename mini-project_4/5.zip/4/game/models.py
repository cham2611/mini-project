from django.db import models

# Create your models here.

# class Action(models.Model):  # 클래스 이름을 'Action'으로 변경
#     name = models.CharField(max_length=255)  # VARCHAR(255) -> CharField
#     genres = models.CharField(max_length=255)  # VARCHAR(255) -> CharField
#     image = models.URLField(max_length=255)  # VARCHAR(255) -> URLField (이미지 URL을 저장)
#     releasedate = models.DateTimeField()  # DATETIME -> DateTimeField
#     price = models.IntegerField()  # INT -> IntegerField