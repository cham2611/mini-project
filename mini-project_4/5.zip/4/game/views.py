from django.shortcuts import render

# from .models import Action  # 모델 이름을 'Action'으로 변경
from django.db import connection

def action_list(request):  # 함수 이름을 'action_list'로 변경 가능
    with connection.cursor() as cursor:
        cursor.execute("SELECT DISTINCT name FROM games_action") 
        names = [row[0] for row in cursor.fetchall()]  # 결과를 리스트로 변환


    # DISTINCT genre 가져오기
    with connection.cursor() as cursor: 
        cursor.execute("SELECT name, max(genres) FROM games_action GROUP BY name")  
        genres = [row[1] for row in cursor.fetchall()]  # 결과를 리스트로 변환


    # DISTINCT genre 가져오기
    with connection.cursor() as cursor:
        cursor.execute("SELECT DISTINCT image FROM games_action")  
        images = [row[0] for row in cursor.fetchall()]  # 결과를 리스트로 변환
    
        # DISTINCT genre 가져오기
    with connection.cursor() as cursor:
        cursor.execute("SELECT name, max(releasedate) FROM games_action GROUP BY name;")  
        releasedates = [row[1] for row in cursor.fetchall()]  # 결과를 리스트로 변환
    
        # DISTINCT genre 가져오기
    with connection.cursor() as cursor:
        cursor.execute("SELECT name, max(price) FROM games_action GROUP BY name;")  
        prices = [row[1] for row in cursor.fetchall()]  # 결과를 리스트로 변환

    result = zip(names, genres, images, releasedates, prices)
    # 템플릿에 데이터 전달
    return render(request, 'action.html', {'result': list(result)})


def action_game_detail(request, name):
    # SQL 쿼리를 사용하여 게임의 세부 정보를 가져옵니다.
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM games_action WHERE name = %s", [name])
        game = cursor.fetchone()  # 첫 번째 결과 가져오기

        # 게임 정보가 존재하는 경우
        if game:
            # SQL 쿼리를 사용하여 해당 게임에 대한 리뷰를 가져옵니다.
            cursor.execute("SELECT reviewtext, reviewscore, playtime_at_review, timestamp_created,author FROM games_action WHERE name = %s", [game[0]])  # game[0]은 게임 ID
            reviews = cursor.fetchall()  # 모든 리뷰 가져오기
            review_data = []
            for review in reviews:
                review_data.append({
                'text': review[0],
                'score': review[1],
                'playtime': review[2],
                'timestamp': review[3],
                'author':review[4]
            })
        else:
            game = None
            review_data = []

    # 게임 정보가 있는 경우에만 context 설정
    context = {
        'game_name': game[0] if game else '게임을 찾을 수 없습니다.',  # game[1]은 게임 이름
        'genre': game[1] if game else '',  # genre
        'price': game[4] if game else '',  # price
        'releasedate': game[3] if game else '',  # releasedate
        'image': game[2] if game else '',  # image
        'reviews': review_data,
    }
    
    return render(request, 'action_game_detail.html', context)




